var sideA = 5;
var sideB = 7;

var biggerSide;

if (sideB > sideA) {
	debugger;
    biggerSide = sideB;
} else {
	debugger;
	biggerSide = sideA;
}

debugger;
console.log(biggerSide);

// var familyName = 'asdas';

// if (!familyName) {
// 	alert("Please enter your family name");
// }

// console.log("after the if statement");