var exam = 5;
var diploma =  6;
var giveMoney = true;

if ((exam === 6 && diploma === 6) || giveMoney) {
	debugger;
	console.log('accepted');
} else {
	debugger;
	console.log('not accepted');
}

console.log('after');