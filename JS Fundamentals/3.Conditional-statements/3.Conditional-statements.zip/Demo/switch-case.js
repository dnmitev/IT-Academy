var day = 2;

switch (day) {
    case 1:
    case 2:
    case 3: debugger;
    case 4:
    case 5:
        debugger;
        console.log('Working day');
        break;
    case 6:
    case 7:
    debugger;
        console.log('Weekend!');
        break;
    default:
        debugger;
        console.log('Error!');
        break;
}

console.log("after");