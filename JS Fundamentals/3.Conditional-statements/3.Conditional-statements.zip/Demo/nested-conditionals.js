var n = 'pesho';

if (!isNaN(n)) {
    if (n % 2) {
    	debugger;
        console.log('Odd!');
    } else {
    	debugger;
        console.log('Even!');
    }
} else {
    debugger;
    console.log('NaN');
}